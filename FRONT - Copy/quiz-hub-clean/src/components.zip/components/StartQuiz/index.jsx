import StartQuiz from "./StartQuiz";
export default StartQuiz;
