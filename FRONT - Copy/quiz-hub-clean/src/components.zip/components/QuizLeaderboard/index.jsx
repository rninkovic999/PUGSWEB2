import QuizLeaderboard from "./QuizLeaderboard";
export default QuizLeaderboard;
